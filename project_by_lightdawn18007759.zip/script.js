document.addEventListener('DOMContentLoaded', () => {
    // Create floating elements dynamically
    function createFloatingElement() {
        const container = document.querySelector('.floating-elements');
        const isHeart = Math.random() > 0.5;
        
        const element = document.createElement('div');
        element.classList.add(isHeart ? 'floating-heart' : 'floating-flower');
        
        // Random position
        element.style.left = `${Math.random() * 100}%`;
        element.style.animationDelay = `${Math.random() * 8}s`;
        element.style.animationDuration = `${8 + Math.random() * 4}s`;
        
        container.appendChild(element);
        
        // Remove element after animation
        setTimeout(() => {
            element.remove();
        }, 12000);
    }
    
    // Create floating elements periodically
    setInterval(createFloatingElement, 2000);
    
    // Add hover effects to detail cards
    const detailCards = document.querySelectorAll('.detail-card');
    detailCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-8px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Add sparkle effect on click
    document.addEventListener('click', (e) => {
        createSparkle(e.clientX, e.clientY);
    });
    
    function createSparkle(x, y) {
        const sparkle = document.createElement('div');
        sparkle.style.position = 'fixed';
        sparkle.style.left = x + 'px';
        sparkle.style.top = y + 'px';
        sparkle.style.width = '8px';
        sparkle.style.height = '8px';
        sparkle.style.background = '#4169e1';
        sparkle.style.borderRadius = '50%';
        sparkle.style.pointerEvents = 'none';
        sparkle.style.zIndex = '1000';
        sparkle.style.animation = 'sparkle 1s ease-out forwards';
        
        document.body.appendChild(sparkle);
        
        setTimeout(() => sparkle.remove(), 1000);
    }
});